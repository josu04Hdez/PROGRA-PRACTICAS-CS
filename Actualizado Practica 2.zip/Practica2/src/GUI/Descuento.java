package GUI;


public class Descuento {
    
}
