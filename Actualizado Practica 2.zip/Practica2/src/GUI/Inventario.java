
package GUI;

import javax.swing.JOptionPane; 

public class Inventario {
    private Producto[] productos = new Producto[100];
    private int contador = 0;

    public void menuProductos() {
        int opcion = 0;

        do {
            try {
                opcion = Integer.parseInt(JOptionPane.showInputDialog(
                        "=== MENÚ DE PRODUCTOS ===\n"
                        + "1. Agregar productos\n"
                        + "2. Ver productos\n"
                        + "3. Volver\n"
                        + "Seleccione una opción:"));

                switch (opcion) {
                    case 1:
                        agregarProductos();
                        break;
                    case 2:
                        mostrarProductos();
                        break;
                    case 3:
                        JOptionPane.showMessageDialog(null, "Regresando al menú principal...");
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opción incorrecta.");
                }

            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Debe ingresar un número válido.");
            }

        } while (opcion != 3);
    }

    private void agregarProductos() {
        try {
            int cantidadAgregar = Integer.parseInt(JOptionPane.showInputDialog(
                    "¿Cuántos productos desea agregar?"));

            for (int i = 0; i < cantidadAgregar; i++) {
                if (contador >= productos.length) {
                    JOptionPane.showMessageDialog(null, "No se pueden agregar más productos (límite alcanzado).");
                    break;
                }

                JOptionPane.showMessageDialog(null, "Producto #" + (i + 1));

                String codigo = JOptionPane.showInputDialog("Código del producto:");
                String nombre = JOptionPane.showInputDialog("Nombre del producto:");
                double precio = Double.parseDouble(JOptionPane.showInputDialog("Precio:"));
                int cantidad = Integer.parseInt(JOptionPane.showInputDialog("Cantidad disponible:"));

                productos[contador] = new Producto(codigo, nombre, precio, cantidad);
                contador++;
            }

            JOptionPane.showMessageDialog(null, "Productos agregados correctamente.");

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Debe ingresar números válidos.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ocurrió un error al agregar productos.");
        }
    }

    private void mostrarProductos() {
        if (contador == 0) {
            JOptionPane.showMessageDialog(null, "No hay productos registrados.");
        } else {
            String lista = "=== LISTA DE PRODUCTOS ===\n";
            for (int i = 0; i < contador; i++) {
                lista += productos[i].toString() + "\n";
            }
            JOptionPane.showMessageDialog(null, lista);
        }
    }
}
